/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controlador;

import Conec.consultasDb;
import Modelo.TrabajadorPlanta;
import Modelo.Trabajdor;
import Vista.VistaHome;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.util.AbstractList;
import java.util.ArrayList;
import java.util.List;
import javax.swing.JOptionPane;
import javax.swing.table.DefaultTableModel;

/**
 *
 * @author C063374
 */
public class ControladorVistaHome implements ActionListener {

    private VistaHome vistaHome;

    private TrabajadorPlanta trabjadorPlanta;

    List<Trabajdor> listaTrabajdor;

    DefaultTableModel modelo;

    public ControladorVistaHome() {
        this.vistaHome = new VistaHome();
        this.listaTrabajdor = new ArrayList<>();
        this.modelo = (DefaultTableModel) this.vistaHome.tablaTrabajador.getModel();
    }

    public void iniciaVista() {
        this.vistaHome.setTitle("Vista Home");
        this.vistaHome.setLocationRelativeTo(null);
        this.vistaHome.btnAdd.addActionListener(this);
        this.vistaHome.btnDelete.addActionListener(this);
        this.vistaHome.btnUdpate.addActionListener(this);

        this.vistaHome.setVisible(true);
    }

    private boolean crearTrabajadorPlanta() {
        consultasDb nuevo = new consultasDb();
        nuevo.crearTrabajador(this.vistaHome.txtRut.getText(), this.vistaHome.txtNombre.getText(), this.vistaHome.txtCorreo.getText());
        return true;
    }

    private boolean agrgarTrabajdorLista() {
        try {
            
            limpiarGrilla();
            consultasDb getTrabajador = new consultasDb();
            ResultSet get = getTrabajador.getTrabajador();
            while (get.next()) {
                modelo.addRow(new Object[]{get.getInt("Id"), get.getString("nombre"), get.getString("correo")});
            }
            return true;
        } catch (Exception e) {
            return false;
        }
    }

    private void eliminarelemento() {
        
//        String id = this.vistaHome.tablaTrabajador.getValueAt(this.vistaHome.tablaTrabajador.getSelectedRow(), 0).toString();
//        for (int i = 0; i < listaTrabajdor.size(); i++) {
//            if (listaTrabajdor.get(i).getRut().equals(id)) {
//                listaTrabajdor.remove(i);
//            }
//        }
//        return id;
        consultasDb nuevo = new consultasDb();
        nuevo.deleteTrabajador(this.vistaHome.txtRut.getText(), this.vistaHome.txtNombre.getText(), this.vistaHome.txtCorreo.getText());
        
    }
    

    private void actualizarElemento() {

        consultasDb nuevo = new consultasDb();
        nuevo.updateTrabajador(this.vistaHome.txtRut.getText(), this.vistaHome.txtNombre.getText(), this.vistaHome.txtCorreo.getText());

    }

    private void limpiarGrilla() {
        while (modelo.getRowCount() > 0) {
            modelo.removeRow(0);
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if (e.getSource() == this.vistaHome.btnAdd) {
            System.out.println("se disparo el evento");
            crearTrabajadorPlanta();
            agrgarTrabajdorLista();
        }

        if (e.getSource() == this.vistaHome.btnDelete) {
            eliminarelemento();
            agrgarTrabajdorLista();
        }

        if (e.getSource() == this.vistaHome.btnUdpate) {
            System.out.println("se disparo el evento");
            if (this.vistaHome.txtRut.getText().equals("")) {
                JOptionPane.showMessageDialog(null, "Favor ingresar un rut para actualizar");
            } else {
                actualizarElemento();
                agrgarTrabajdorLista();
            }
        }

    }
}
