/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conec;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author macos
 */
public class consultasDb {

    ConexionDb cn;

    public ResultSet getTrabajador() {
        ResultSet consulta = null;

        try {
            cn = new ConexionDb();
            cn.conectar();
            String qry = "Select * from ejerdc";
            consulta = cn.conexion.createStatement().executeQuery(qry);
        } catch (SQLException ex) {
            Logger.getLogger(consultasDb.class.getName()).log(Level.SEVERE, null, ex);

        }
        return consulta;

    }

    public void crearTrabajador(String Rut, String nombre, String correo) {
        try {

            cn = new ConexionDb();
            cn.conectar();
            String qry = "Insert into ejerdc(Rut,nombre,correo) values ('" + Rut + "','" + nombre + "','" + correo + "')";
            int executar = cn.conexion.createStatement().executeUpdate(qry);
        } catch (SQLException ex) {
            Logger.getLogger(consultasDb.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public void updateTrabajador(String Rut, String nombre, String correo) {
        try {
            cn = new ConexionDb();
            cn.conectar();
            String qry = "UPDATE ejerdc SET nombre = '" + nombre + "' , correo = '" + correo + "'WHERE ID = '" + Rut + "'";

            int executar = cn.conexion.createStatement().executeUpdate(qry);
        } catch (SQLException ex) {
            Logger.getLogger(consultasDb.class.getName()).log(Level.SEVERE, null, ex);

        }
    }

    public void deleteTrabajador(String Rut, String nombre,String correo){
        try{
            cn = new ConexionDb();
            cn.conectar();
            String qry = "DELETE FROM ejerdc WHERE id='"+Rut+"'";
            
            int excutar = cn.conexion.createStatement().executeUpdate(qry);
        }catch (SQLException ex){
            Logger.getLogger(consultasDb.class.getName()).log(Level.SEVERE,null,ex);
        }
    }
    
}
