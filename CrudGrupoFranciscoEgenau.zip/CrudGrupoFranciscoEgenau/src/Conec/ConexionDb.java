/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Conec;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author macos
 */
public class ConexionDb {
    
    Connection conexion = null;
    
    public Connection conectar(){
        try{
            Class.forName("com.mysql.cj.jdbc.Driver");
            conexion = DriverManager.getConnection("jdbc:mysql://localhost:3306/ejercdb","root","");
            System.out.println("Conexxion ok");
        } catch (Exception ex){
            System.out.println("Conexion con problemas : "+ex.getMessage());
            
        }
        return conexion;
    }
    
    public void desconectar (){
        try{
            conexion.close();
        } catch (Exception ex){
            System.out.println("Conexion con problemas al cerrar: "+ex.getMessage());
        }
    }    
}
